class Dancer
  attr_reader :name
  attr_accessor :age
  
  def initialize(name, age)
    @name = name
    @age = age
    dancers = {@name => @age}
  end

  def pirouette
    puts "*twirls*"
  end 

  def bow
    puts "*bows*"
  end 

  def card
    card = Array.new
  end  

  def queue_dance_with(partner)
    card.push(partner)
  end  

  def begin_next_dance
    index = card[0]
    puts "Now dancing with #{index}."

   def leap
    puts "*leap*"
   end  
    
  end
end


#I would like some guidance on using rspec. When I paired for 6.6 it was working perfectly and when I was doing this quiz I kept getting examples 0, so I could never really test anything.

